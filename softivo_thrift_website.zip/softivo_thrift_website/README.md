# Softivo Thrift — custom online store starter

This is a custom-coded, mobile-friendly thrift storefront with:
- Product collections (Dresses, Tops, Skirts)
- Single-piece inventory behaviour (the same item cannot be added twice to one cart)
- Shopping bag and checkout form
- Razorpay integration scaffolding (secure server-side order creation and signature verification)
- Responsive boutique styling

## Important before launch

This is a working starter website, not yet a live store. The sample products are placeholders. Real payments are **not enabled** until the store owner creates a Razorpay account and adds API credentials securely to the hosting environment. Do not put the Razorpay secret key in browser code.

The current checkout does not save orders to a database, send order emails, calculate shipping, or automatically mark inventory sold after a verified payment. Those are important production features to add before accepting customer orders. For now, use Razorpay test mode only while testing.

## Run on your computer

1. Install Node.js (LTS) from https://nodejs.org/
2. Unzip this folder.
3. Open a terminal in this folder and run:
   ```bash
   npm install
   ```
4. Copy `.env.example` to `.env`.
5. Run:
   ```bash
   npm start
   ```
6. Open http://localhost:3000

## Add your products

Edit `PRODUCTS` at the top of `public/app.js`. Example:

```js
{
  id: "dress-003",
  name: "Floral Midi Dress",
  category: "Dresses",
  price: 650,
  size: "M",
  image: "/images/floral-midi.jpg",
  available: true
}
```

Put the product image in `public/images/`. Use a unique `id` for every item. Set `available: false` for sold-out items.

For one-of-a-kind thrift pieces, use one product entry per physical item. The current cart prevents adding the same item twice to one shopper's cart, but it does not yet reserve stock across different shoppers. A database and server-side stock locking are needed to prevent simultaneous purchases.

## Connect Razorpay

1. Create and verify a Razorpay merchant account.
2. Get API keys from the Razorpay dashboard. Start with **test mode**.
3. Set `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` in the server/hosting environment (not in `public/`).
4. Deploy the Node app to a host that supports a Node server.
5. Test successful, failed and cancelled payments before switching to live keys.

Payment gateway onboarding and eligibility are determined by Razorpay. UPI availability depends on the account and checkout configuration.

## Free hosting

This app needs a Node.js host because payment order creation and verification run on the server. You can explore free-tier Node hosting providers, but free tiers, sleep limits and custom-domain support can change. A free subdomain may be available. A custom domain is optional and usually costs extra.

## Before taking real orders, add

- Database-backed product inventory and atomic stock reservation
- Saving customer/order records after verified payment
- Order confirmation email/WhatsApp workflow
- Shipping fee rules and delivery policy
- Admin interface for adding products and marking them sold
- Privacy policy, terms, returns/refunds and contact details
- Security, rate limiting, validation, backups and deployment checks

Do not publish real customer data or accept live payments until these are completed and tested.
