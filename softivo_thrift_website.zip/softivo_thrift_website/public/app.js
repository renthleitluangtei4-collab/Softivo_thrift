// Add or edit products in this list. Keep each product's id unique.
const PRODUCTS = [
  { id: "dress-001", name: "Floral Reverie Dress", category: "Dresses", price: 650, size: "M", image: "", available: true },
  { id: "dress-002", name: "Sunday Garden Dress", category: "Dresses", price: 600, size: "S", image: "", available: true },
  { id: "top-001", name: "Everyday Vintage Top", category: "Tops", price: 350, size: "Free size", image: "", available: true },
  { id: "skirt-001", name: "Soft Petal Skirt", category: "Skirts", price: 400, size: "M", image: "", available: true }
];

let cart = [];
let currentFilter = "All";
let paymentConfig = { razorpayEnabled: false, razorpayKeyId: null };

const $ = (id) => document.getElementById(id);
const rupees = (amount) => "₹" + Number(amount).toLocaleString("en-IN");

function showToast(message) {
  const toast = $("toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("show"), 2500);
}

function renderProducts() {
  const visible = PRODUCTS.filter(p => (currentFilter === "All" || p.category === currentFilter));
  $("product-grid").innerHTML = visible.map(p => `
    <article class="product-card">
      <div class="product-photo">
        ${p.image ? `<img src="${escapeHtml(p.image)}" alt="${escapeHtml(p.name)}" loading="lazy">` : `<div class="photo-placeholder">${escapeHtml(p.category)}<small>SOFTIVO THRIFT</small></div>`}
        ${p.available ? "" : '<span class="sold-label">SOLD OUT</span>'}
      </div>
      <div class="product-info">
        <h3 class="product-name">${escapeHtml(p.name)}</h3>
        <div class="product-meta"><span>${escapeHtml(p.size || "See details")}</span><span class="product-price">${rupees(p.price)}</span></div>
        <button class="add-button" data-add="${escapeHtml(p.id)}" ${p.available ? "" : "disabled"}>${p.available ? "Add to bag" : "Sold out"}</button>
      </div>
    </article>`).join("");
  $("empty-note").hidden = visible.length > 0;
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, ch => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[ch]));
}

function addToCart(id) {
  const product = PRODUCTS.find(p => p.id === id);
  if (!product || !product.available) return;
  if (cart.some(item => item.id === id)) {
    showToast("This is a one-of-a-kind piece — only one available.");
    return;
  }
  cart.push({ ...product });
  renderCart();
  showToast("Added to your bag ♡");
}

function removeFromCart(id) {
  cart = cart.filter(item => item.id !== id);
  renderCart();
}

function renderCart() {
  $("cart-count").textContent = cart.length;
  $("cart-items").innerHTML = cart.length ? cart.map(p => `
    <div class="cart-row">
      <div class="cart-thumb">${escapeHtml(p.category)}</div>
      <div><strong>${escapeHtml(p.name)}</strong><small>${escapeHtml(p.size)} · ${rupees(p.price)}</small><button class="remove-item" data-remove="${escapeHtml(p.id)}">Remove</button></div>
      <b>${rupees(p.price)}</b>
    </div>`).join("") : '<p class="empty-note">Your bag is waiting for something lovely ♡</p>';
  const total = cart.reduce((sum, p) => sum + p.price, 0);
  $("subtotal").textContent = rupees(total);
  $("checkout-total").textContent = rupees(total);
}

function openCart() {
  $("overlay").classList.add("show");
  $("cart-drawer").classList.add("open");
  $("cart-drawer").setAttribute("aria-hidden", "false");
}
function closeCart() {
  $("overlay").classList.remove("show");
  $("cart-drawer").classList.remove("open");
  $("cart-drawer").setAttribute("aria-hidden", "true");
}
function openCheckout() {
  if (!cart.length) return showToast("Your bag is empty.");
  closeCart();
  $("checkout-modal").classList.add("show");
  $("checkout-modal").setAttribute("aria-hidden", "false");
}
function closeCheckout() {
  $("checkout-modal").classList.remove("show");
  $("checkout-modal").setAttribute("aria-hidden", "true");
}

async function startPayment(formData) {
  if (!paymentConfig.razorpayEnabled || !window.Razorpay) {
    showToast("Payments aren't connected yet. Please contact the store to complete your order.");
    $("payment-hint").textContent = "The store owner needs to connect a payment gateway before customers can pay online. No payment has been taken.";
    return;
  }
  const total = cart.reduce((sum, p) => sum + p.price, 0);
  $("pay-button").disabled = true;
  $("pay-button").textContent = "Preparing secure payment…";
  try {
    const orderResponse = await fetch("/api/create-order", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ amount: total * 100 })
    });
    const order = await orderResponse.json();
    if (!orderResponse.ok) throw new Error(order.error || "Could not create payment.");

    const options = {
      key: paymentConfig.razorpayKeyId,
      amount: order.amount,
      currency: order.currency,
      name: "Softivo Thrift",
      description: "Your handpicked thrift finds",
      order_id: order.orderId,
      prefill: { name: formData.name, email: formData.email, contact: formData.phone },
      notes: { delivery_address: formData.address },
      theme: { color: "#b77f78" },
      handler: async function (response) {
        const verifyResponse = await fetch("/api/verify-payment", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(response)
        });
        const verified = await verifyResponse.json();
        if (!verifyResponse.ok || !verified.verified) {
          showToast("We couldn't verify the payment. Please contact the store.");
          return;
        }
        showToast("Payment successful — thank you for shopping with us ♡");
        cart = [];
        renderCart();
        closeCheckout();
      },
      modal: { ondismiss: () => showToast("Checkout closed. Your bag is saved.") }
    };
    const checkout = new window.Razorpay(options);
    checkout.open();
  } catch (error) {
    showToast(error.message || "Payment could not be started.");
  } finally {
    $("pay-button").disabled = false;
    $("pay-button").textContent = "Pay securely";
  }
}

$("product-grid").addEventListener("click", e => {
  const button = e.target.closest("[data-add]");
  if (button) addToCart(button.dataset.add);
});
$("cart-items").addEventListener("click", e => {
  const button = e.target.closest("[data-remove]");
  if (button) removeFromCart(button.dataset.remove);
});
$("filters").addEventListener("click", e => {
  const button = e.target.closest("[data-filter]");
  if (!button) return;
  currentFilter = button.dataset.filter;
  document.querySelectorAll(".filter").forEach(el => el.classList.toggle("active", el === button));
  renderProducts();
});
document.querySelectorAll("[data-filter-link]").forEach(link => link.addEventListener("click", () => {
  currentFilter = link.dataset.filterLink;
  document.querySelectorAll(".filter").forEach(el => el.classList.toggle("active", el.dataset.filter === currentFilter));
  renderProducts();
}));
$("open-cart").addEventListener("click", openCart);
$("close-cart").addEventListener("click", closeCart);
$("overlay").addEventListener("click", closeCart);
$("checkout-button").addEventListener("click", openCheckout);
$("close-checkout").addEventListener("click", closeCheckout);
$("checkout-modal").addEventListener("click", e => { if (e.target === $("checkout-modal")) closeCheckout(); });
$("checkout-form").addEventListener("submit", async e => {
  e.preventDefault();
  if (!cart.length) return showToast("Your bag is empty.");
  const data = Object.fromEntries(new FormData(e.currentTarget).entries());
  await startPayment(data);
});
$("year").textContent = new Date().getFullYear();

renderProducts();
renderCart();
fetch("/api/config").then(r => r.json()).then(config => {
  paymentConfig = config;
  $("payment-hint").textContent = config.razorpayEnabled
    ? "Your payment will be processed securely by Razorpay."
    : "Online payment is not connected yet. The store owner must add Razorpay API keys before taking payments.";
}).catch(() => {});
