require("dotenv").config();
const express = require("express");
const path = require("path");
const Razorpay = require("razorpay");

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const hasRazorpayKeys =
  process.env.RAZORPAY_KEY_ID &&
  process.env.RAZORPAY_KEY_SECRET &&
  process.env.RAZORPAY_KEY_ID !== "rzp_test_replace_me";

let razorpay;
if (hasRazorpayKeys) {
  razorpay = new Razorpay({
    key_id: process.env.RAZORPAY_KEY_ID,
    key_secret: process.env.RAZORPAY_KEY_SECRET
  });
}

app.get("/api/config", (_req, res) => {
  res.json({
    razorpayEnabled: Boolean(razorpay),
    razorpayKeyId: razorpay ? process.env.RAZORPAY_KEY_ID : null
  });
});

app.post("/api/create-order", async (req, res) => {
  if (!razorpay) {
    return res.status(503).json({
      error: "Online payment is not configured yet. Add your Razorpay API keys to the hosting environment."
    });
  }

  const amount = Number(req.body.amount);
  if (!Number.isInteger(amount) || amount < 100 || amount > 5000000) {
    return res.status(400).json({ error: "Invalid payment amount." });
  }

  try {
    const order = await razorpay.orders.create({
      amount,
      currency: "INR",
      receipt: `softivo_${Date.now()}`
    });
    res.json({ orderId: order.id, amount: order.amount, currency: order.currency });
  } catch (error) {
    console.error("Razorpay order error:", error);
    res.status(500).json({ error: "Could not start checkout. Please try again." });
  }
});

app.post("/api/verify-payment", (req, res) => {
  const crypto = require("crypto");
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;

  if (!process.env.RAZORPAY_KEY_SECRET) {
    return res.status(503).json({ error: "Payment verification is not configured." });
  }

  const expected = crypto
    .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
    .update(`${razorpay_order_id}|${razorpay_payment_id}`)
    .digest("hex");

  const safe = (a, b) => {
    const ba = Buffer.from(String(a || ""));
    const bb = Buffer.from(String(b || ""));
    return ba.length === bb.length && crypto.timingSafeEqual(ba, bb);
  };

  if (!safe(expected, razorpay_signature)) {
    return res.status(400).json({ verified: false, error: "Payment verification failed." });
  }
  res.json({ verified: true });
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Softivo Thrift is running on port ${port}`));
